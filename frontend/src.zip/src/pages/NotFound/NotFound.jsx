function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <h1 className="text-5xl font-bold text-red-500">
        404 - Page Not Found
      </h1>
    </div>
  );
}

export default NotFound;