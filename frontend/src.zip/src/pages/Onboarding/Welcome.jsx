import { ArrowRight, PartyPopper } from "lucide-react";
import { useNavigate } from "react-router-dom";

import Button from "../../components/ui/Button";
import { useAuth } from "../../context/AuthContext";

function Welcome() {
  const navigate = useNavigate();
  const { user } = useAuth();

  return (
    <div className="text-center">
      <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-[#12C29D]/10">
        <PartyPopper className="h-10 w-10 text-[#12C29D]" />
      </div>

      <h1 className="text-4xl font-bold text-[#081B33]">
        Welcome{user?.name ? `, ${user.name}` : ""}! 🎉
      </h1>

      <p className="mt-5 text-lg leading-8 text-slate-600">
        Your ExpenseFlow account has been created successfully.
      </p>

      <p className="mt-3 text-slate-500">
        Let's personalize your experience before you start managing your
        finances.
      </p>

      <div className="mt-10 rounded-2xl border border-[#12C29D]/20 bg-[#12C29D]/5 p-5">
        <p className="font-medium text-[#081B33]">
          This setup takes less than a minute.
        </p>

        <p className="mt-2 text-sm text-slate-500">
          We'll ask you to choose your preferred language and default currency.
        </p>
      </div>

      <Button
        className="mt-10"
        onClick={() => navigate("/onboarding/language")}
      >
        Continue
        <ArrowRight className="ml-2 h-5 w-5" />
      </Button>
    </div>
  );
}

export default Welcome;